#!/usr/bin/env bash
set -euo pipefail

# macOS one-shot build script for Black Gold Coin (daemon, CLI, and optional Qt GUI)
# Usage:
#   ./contrib/macos/build.sh                # default: GUI ON, BDB OFF, ZMQ OFF, UPNP OFF
#   BUILD_GUI=OFF ./contrib/macos/build.sh  # headless
#   WITH_BDB=ON ./contrib/macos/build.sh    # enable legacy (BDB) wallets
#   WITH_ZMQ=ON ./contrib/macos/build.sh    # enable ZMQ notifications
#   WITH_MINIUPNPC=ON ./contrib/macos/build.sh # enable UPnP
#   DEPLOY=1 ./contrib/macos/build.sh       # also produce .app and zip
#
# Notes:
# - Requires Xcode Command Line Tools (xcode-select --install)
# - Requires Homebrew (https://brew.sh)

BUILD_GUI="${BUILD_GUI:-ON}"
WITH_BDB="${WITH_BDB:-OFF}"
WITH_ZMQ="${WITH_ZMQ:-OFF}"
WITH_MINIUPNPC="${WITH_MINIUPNPC:-OFF}"
DEPLOY="${DEPLOY:-0}"
BUILD_DIR="${BUILD_DIR:-build}" # override if desired

# 1) Sanity checks
if ! command -v xcode-select >/dev/null; then
  echo "xcode-select not found. Install Xcode Command Line Tools first: xcode-select --install" >&2
  exit 1
fi
if ! xcode-select -p >/dev/null 2>&1; then
  echo "Xcode Command Line Tools not installed. Run: xcode-select --install" >&2
  exit 1
fi
if ! command -v brew >/dev/null; then
  echo "Homebrew is required. Install from https://brew.sh, then re-run." >&2
  exit 1
fi

# 2) Install dependencies
COMMON_FORMULAE=(cmake boost pkg-config libevent sqlite)
GUI_FORMULAE=(qt@5 qrencode)
BDB_FORMULA=(berkeley-db@4)
ZMQ_FORMULA=(zeromq)
UPNP_FORMULA=(miniupnpc)

brew update
brew install "${COMMON_FORMULAE[@]}"
if [[ "${BUILD_GUI}" == "ON" ]]; then
  brew install "${GUI_FORMULAE[@]}"
fi
if [[ "${WITH_BDB}" == "ON" ]]; then
  brew install "${BDB_FORMULA[@]}"
fi
if [[ "${WITH_ZMQ}" == "ON" ]]; then
  brew install "${ZMQ_FORMULA[@]}"
fi
if [[ "${WITH_MINIUPNPC}" == "ON" ]]; then
  brew install "${UPNP_FORMULA[@]}"
fi

# 3) Compute helpful prefixes (universal for Intel/Apple Silicon)
QT_PREFIX="$(brew --prefix qt@5 2>/dev/null || true)"
BDB_PREFIX="$(brew --prefix berkeley-db@4 2>/dev/null || true)"

# Ensure CMake sees Qt (and other keg-only pkgs) without manual flags
export CMAKE_PREFIX_PATH="${QT_PREFIX}:${CMAKE_PREFIX_PATH:-}"

# 4) Configure
CONFIGURE_ARGS=(
  -B "${BUILD_DIR}"
  -DCMAKE_BUILD_TYPE=Release
  -DBUILD_GUI="${BUILD_GUI}"
  -DWITH_BDB="${WITH_BDB}"
  -DWITH_ZMQ="${WITH_ZMQ}"
  -DWITH_MINIUPNPC="${WITH_MINIUPNPC}"
)

# If you want to force an SDK/deployment target, uncomment and adjust:
# CONFIGURE_ARGS+=( -DCMAKE_OSX_DEPLOYMENT_TARGET=12.0 )

cmake "${CONFIGURE_ARGS[@]}"

# 5) Build
JOBS=$(sysctl -n hw.ncpu 2>/dev/null || echo 4)
cmake --build "${BUILD_DIR}" -j "${JOBS}"

# 6) Optional tests (requires Python for full test suite)
# ctest --test-dir "${BUILD_DIR}" -j "${JOBS}"

# 7) Optional deploy: create bgcoin-qt.app and zip under build artifacts
if [[ "${DEPLOY}" == "1" && "${BUILD_GUI}" == "ON" ]]; then
  cmake --build "${BUILD_DIR}" --target deploy
  echo "App bundle and zip created under ${BUILD_DIR}."
fi

# 8) Print result locations
echo "\nBuild complete. Binaries:"
if [[ -f "${BUILD_DIR}/src/bgcoind" ]]; then
  echo "  ${BUILD_DIR}/src/bgcoind"
fi
if [[ -f "${BUILD_DIR}/src/bgcoin-cli" ]]; then
  echo "  ${BUILD_DIR}/src/bgcoin-cli"
fi
if [[ -f "${BUILD_DIR}/src/qt/bgcoin-qt" ]]; then
  echo "  ${BUILD_DIR}/src/qt/bgcoin-qt"
fi
if [[ -d "${BUILD_DIR}/src/qt/bgcoin-qt.app" ]]; then
  echo "  ${BUILD_DIR}/src/qt/bgcoin-qt.app"
fi
","file_path":"/home/wen/Downloads/bgcoin-2.0.1/contrib/macos/build.sh","summary":"Add macOS one-shot build script to install deps, configure, build, and optionally deploy .app"}  }```}ंत