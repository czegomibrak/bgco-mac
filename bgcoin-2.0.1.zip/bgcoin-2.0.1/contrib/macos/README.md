# macOS build quickstart

This project already supports macOS via CMake. For a one-shot setup and build on macOS, use the helper script.

Requirements:
- Xcode Command Line Tools (`xcode-select --install`)
- Homebrew (https://brew.sh)

Steps:
1) Clone the repo and cd into it.
2) Make the script executable and run it:

```bash
chmod +x contrib/macos/build.sh
./contrib/macos/build.sh
```

By default this builds:
- bgcoind (daemon)
- bgcoin-cli (CLI)
- bgcoin-qt (GUI)

Artifacts will appear under `build/`.

Options (set env vars before running):
- `BUILD_GUI=OFF` to skip Qt GUI
- `WITH_BDB=ON` to enable legacy wallets (Berkeley DB 4.8)
- `WITH_ZMQ=ON` to enable ZMQ notifications
- `WITH_MINIUPNPC=ON` to enable UPnP
- `DEPLOY=1` to also bundle `bgcoin-qt.app` and create a zip

Examples:
```bash
# Headless only
BUILD_GUI=OFF ./contrib/macos/build.sh

# GUI + legacy wallets + ZMQ, and produce .app zip
WITH_BDB=ON WITH_ZMQ=ON DEPLOY=1 ./contrib/macos/build.sh
```

Troubleshooting:
- Qt not found: the script exports `CMAKE_PREFIX_PATH` to Homebrew's `qt@5` prefix. Ensure `brew install qt@5` completed. If you use non-Homebrew Qt, set `CMAKE_PREFIX_PATH` yourself.
- BDB not found: `brew install berkeley-db@4`. The build system auto-detects the Homebrew keg path.
- Apple Silicon vs Intel: Homebrew prefixes are auto-detected; no action needed.
