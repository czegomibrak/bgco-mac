Sample configuration files for:
```
systemd: bgcoind.service
Upstart: bgcoind.conf
OpenRC:  bgcoind.openrc
         bgcoind.openrcconf
CentOS:  bgcoind.init
macOS:   org.bgcoin.bgcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
